<?php 

	require_once($_SERVER["DOCUMENT_ROOT"]."/autoload.php");

	class mail{
		
		function __construct($a, $b, $c, $d)
		{
			# code...
		}
	}

?>